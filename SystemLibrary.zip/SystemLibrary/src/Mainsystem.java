import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Mainsystem {
	static String fileName = null;
	static Library lib = new Library();
	static Scanner in = new Scanner(System.in);
	static Boolean running = true ;

public static void main(String[] args) {
	while(running){ 
		System.out.println("\nChoose 0 for loading a library." 
		+"\nChoose 1 for Saving and Exit."
		+ "\nChoose 2 for list all books in library."
		+ "\nChoose 3 for adding a  book to library.");
		int ans= in.nextInt(); 
		switch(ans){
		case 0:
			System.out.println("Please , Input the file name to load"); 
			loadScript(in.next());
			break;
		case 1 : 
			SaveandExit();
		    break;
		case 2 : 
			System.out.println(lib.toString());
		    break;
		case 3 :
			addBook();
			break;
	}
}
	System.exit(0);
}
private static void addBook() {
	 int iss;
     String title, author,date;
     double price;
     System.out.println("\nEnter the Title :");
     title=in.next();
     System.out.println("\nEnter author name :");
     author=in.next();
     System.out.println("\nEnter the  iss :");
     iss=in.nextInt();
     System.out.println("\nEnter the price :");
     price=in.nextDouble();
     System.out.println("\nEnter the  return date :");
     date=in.next();
     
     Book bo = new Book(iss,title ,author,price,date);
     lib.addBook(bo);
}
private static void SaveandExit() {
	System.out.println("Enter the file name : ");
	fileName=in.next()+".ser"  ;
	running = false; 
	FileOutputStream fo =null;
	ObjectOutputStream out =null;
	try {
		fo= new FileOutputStream(fileName);
	    out = new ObjectOutputStream(fo);
	    out.writeObject(lib);
	    fo.close();
	    out.close();
	    
      } catch (FileNotFoundException e) {
	    	e.printStackTrace(); 
      } catch (IOException e) {
	    	e.printStackTrace();
      
      }
}
private static void loadScript(String name) {
	FileInputStream fi= null; 
    ObjectInputStream in =null;
   
    File file =new File(name+ ".ser");
    if (file.exists()) {
    try {
    	
    fi= new FileInputStream(file);
    in = new ObjectInputStream(fi);
    lib=(Library)in.readObject();
    fi.close();
    in.close();
    
    } catch (IOException e) {
    	e.printStackTrace(); 
    } catch (ClassNotFoundException e) {
    	e.printStackTrace();
          }
    } else {
    	System.out.println("\nThe file is not exist");
    }
}}
