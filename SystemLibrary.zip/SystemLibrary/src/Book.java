// Name : Lujain Mohamed El-said
//ID: 202002670
//______________________________________________________
import java.io.Serializable;  // class that implements the Serializable interface.
public class Book implements Serializable{ 
	//  three fields : iss, title, and author.
	private int iss; // instance variable 
	private String date;
    private String title, author;
    private double price;
public Book(){
	iss=0;
     title= null; 
     author =null;
     date=null;
     price = 0;
}
public Book (int iss, String title, String author, double price,String date){ 
//this :  refers to the current object in a method or constructor.
	this.iss= iss;
	this.title =title;
    this.author= author; 
    this.price =price;
    this.date=date;
}
 public String toString(){ // method called toString() 
	 return "\nTitle:" + title+ "\nAuthor: "+ author +"\nIss:" + iss + "\nPrice: "+price+
			 "\n"+"\nDate"+date+"\n"; 
 }
}