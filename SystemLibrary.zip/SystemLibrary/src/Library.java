import java.io.Serializable; 
import java.util.ArrayList; // 
import java.util.List; // ordered collection of objects in which duplicate values can be stored
import java.util.Iterator; // object that can be used to loop through collections

public class Library extends Object implements Serializable {
		private List<Book> collection;
        public Library(){
        	collection= new ArrayList<Book>();}
        
public void addBook( Book book) {  // addBook method adds a book to this list.
	collection.add(book);       }

public String toString() {
	String total= "\n"; 
	/*for (int i=0; i<collection.size(); i++){
		Book bo= collection.get(i);
		total = total +bo.toString(); }
		*/
      Iterator<Book> i = collection.iterator(); //  iterates through the collection
      while (i.hasNext()) {
    	  Book bo= (Book)i.next();
  		  total = total +bo.toString(); 
      }
      return total; 
}
}
